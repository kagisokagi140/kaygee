<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> Form Registration</title>
        <link rel="stylesheet" href="stylecss.css">
    </head>

    <body>
        <div class="box">
            <div class="form"></div>
                <h2>Form Registration</h2>
</body>
</html><?php /**PATH C:\xampp\htdocs\LaravelProjects\NEW\resources\views/CRUD/index.blade.php ENDPATH**/ ?>