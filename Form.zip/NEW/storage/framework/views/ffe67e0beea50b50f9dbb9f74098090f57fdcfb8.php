<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="form-group col-12-p-0">
        <div>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
            <?php endif; ?>
        </div>
    <form action="<?php echo e(route('store')); ?>" method="POST">
        <div class="form-group">
            <div class="col-sm-12">
                <h2 style="text-align:center; color:blue;">Student Details </h2>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-6">
                <label>Student Name</label>
                <input type="text" name="studname" class="form-control" id="studname" placeholder="Enter student name">
            </div>
            <div class="form-group col-md-6">
                <label>Course</label>
                <input type="text" name="course" class="form-control" id="course" placeholder="Enter course name">
            </div>
            <div class="form-group col-md-6">
                <label>Fee</label>
                <input type="text" name="fee" class="form-control" id="fee" placeholder="Enter fees">
            </div>

            <div class="form-group col-md-6" align="center">
                <button class="btn btn-success" style="width:80px;">Submit</button>
            </div>
        </div>
    </form>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\LaravelProjects\NEW\resources\views/index.blade.php ENDPATH**/ ?>