<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>create</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" >
</head>
<style>
    *{
        box-sizing:border-box;
        margin:0;
        padding:0;
    }
    body{
        background:grey;
    }
    form{
        box-shadow:2px 6px 100px #ffffff; 
    }
</style>
<body>
  <div class="container-fluid bg-dark text-light py-3"><h1 class=display-6 >Form</h1></div>
    <div>
        <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>
    <section class="container my-2 bg-dark w-50 text-light p-2">
    <form class="row g-3 p-3" action="<?php echo e(route('CRUD.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
       
<div class="col-md-6">
    <label for="Inputname" class="form-label p-2">Name</label>
    <input class="col-md-8" type="text" name="name" id="Inputname" placeholder="enter name" required>
</div>

<div class="col-md-6">
    <label for="Inputsurname" class="form-label p-2">Surname</label>
    <input class="col-md-8 type="text" name="surname" id="inputsurname" placeholder="enter surname" required>
</div>

<div class="col-12" >
    <label for="Inputemail" class="form-label p-2">Email</label>
    <input class="col-md-12" type="text" name="email" id="Inputemail" placeholder="enter email" required>
</div>
<div class="col-12">
  <label for="gender" class="form-label p-2">Gender</label>
   <select  class="col-md-12 w-50" id="gender" name="gender" required>
        <option value="">Select</option>
        <option value="female">Female</option>
        <option value="male">Male</option>
        <option value="other">Other</option>
    </select>
 </div>
     <div class=" col-12">
         <span class="p-2"> Strengths</span>
         <textarea class="textarea col-md-12 my-2 p-2" value="" name="strengths" id="strengths" required ></textarea>
     </div>
     <div class=" col-12">
         <span class="p-2"> Weaknesses </span>
          <textarea class="textarea col-md-12 my-2 p-2" value="" name="weaknesses" id="weaknesses" required></textarea>
     </div>
<div>
    <input class="my-3" type="submit" value="Save" />
</div>
    </form>
</section>
</body>
</html><?php /**PATH C:\xampp\htdocs\LaravelProjects\NEW\resources\views/CRUD/create.blade.php ENDPATH**/ ?>