<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\form;

class LaravelCRUD extends Controller
{
    //
   public function index(){
    return view('CRUD.index');
   }

   public function create(){
    return view('CRUD.create');
   } 

   public function store(Request $request){
    $data = $request->validate([
        'name'=>'nullable',
        'surname'=>'nullable',
        'email'=>'email',
        'gender'=>'nullable',
        'strengths'=>'nullable',
        'weaknesses'=>'nullable'
        

    ]);

    $newform = form::create($data);

    return redirect(route('CRUD.index'));
   }
}
