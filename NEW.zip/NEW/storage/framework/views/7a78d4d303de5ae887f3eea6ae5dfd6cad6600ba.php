<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>create</title>
</head>
<body>
    <h1>Form</h1>
    <div>
        <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>
    <form action="<?php echo e(route('CRUD.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
       
<div>
    <label>Name</label>
    <input type="text" name="name" placeholder="enter name">
</div>

<div>
    <label>Surname</label>
    <input type="text" name="surname" placeholder="enter surname">
</div>

<div>
    <label>Email</label>
    <input type="text" name="email" placeholder="enter email">
</div>

<div>
    <input type="submit" value="Save" />
</div>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\LaravelProjects\NEW\resources\views/CRUD/create.blade.php ENDPATH**/ ?>